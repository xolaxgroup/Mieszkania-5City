
fx_version "bodacious"
games {"gta5"}
author {"xolax"}
description {"Skrypt na Ustawianie pedow np ochroniarza na szpitalu albo do targetu"}

client_scripts {

  'client/client.lua',
  'client/target.lua'

}
