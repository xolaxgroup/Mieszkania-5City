-------------------------------BY XOLAX GROUP DEVELOPMENT-----------------------------------------------------
XOLAX              = {}

XOLAX.Zones = {
		Wyciaganie =	{
		Pos = {
		{x = -271.06, y = -957.83, z = 30.31, name = 'ped', h = 297.1,		sprite = 51,	color = 59}, -- mieszkania
		},
		}
	} 



ESX = nil


Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)

Citizen.CreateThread(function() --Tworzenie Funkcji
    
    RequestModel(GetHashKey("ig_fbisuit_01"))  -- Ustawiamy model
    while not HasModelLoaded(GetHashKey("ig_fbisuit_01")) do -- tu tak samo model
      Wait(1)
    end

	for k,v in pairs(XOLAX.Zones) do --parowanie z kordami
		for i = 1, #v.Pos, 1 do -- Pozycja
			local pedwyciaganie =  CreatePed(4, 0x3AE4A33B, v.Pos[i].x, v.Pos[i].y, v.Pos[i].z-0.1, v.Pos[i].h, false, true) --Creatowanie Peda w MIEJSCU PO 4 USTAW HASH i pozmienaj nazwe strefy
			SetEntityHeading(pedwyciaganie, v.Pos[i].h) --nazwa locala peda i ustawienie headingu
			FreezeEntityPosition(pedwyciaganie, true) -- nazwa locala peda i Freezowanie go
			SetEntityInvincible(pedwyciaganie, true) --nazwa locala peda i niesmiertelnosc
			SetBlockingOfNonTemporaryEvents(pedwyciaganie, true) 
		end
	end
	  
end)	





-- Citizen.CreateThread(function() --Tworzenie Funkcji
    
--     RequestModel(GetHashKey("ig_fbisuit_01"))  -- Ustawiamy model
--     while not HasModelLoaded(GetHashKey("ig_fbisuit_01")) do -- tu tak samo model
--       Wait(1)
--     end

-- 	for k,v in pairs(XOLAX.Zones) do --parowanie z kordami
-- 		for i = 1, #v.Pos, 1 do -- Pozycja
-- 			local pedwyciaganie =  CreatePed(4, pedmieszkania, v.Pos[i].x, v.Pos[i].y, v.Pos[i].z-0.1, v.Pos[i].h, false, true) --Creatowanie Peda w MIEJSCU PO 4 USTAW HASH i pozmienaj nazwe strefy
-- 			SetEntityHeading(pedmieszkania, v.Pos[i].h) --nazwa locala peda i ustawienie headingu
-- 			FreezeEntityPosition(pedmieszkania, true) -- nazwa locala peda i Freezowanie go
-- 			SetEntityInvincible(pedmieszkania, true) --nazwa locala peda i niesmiertelnosc
-- 			SetBlockingOfNonTemporaryEvents(pedmieszkania, true) 
-- 		end
-- 	end
	  
-- end)	

--Teleport
Citizen.CreateThread(function()
  while ESX == nil do
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Citizen.Wait(25)
  end
end)

RegisterNetEvent('esx:playerLoaded')
AddEventHandler('esx:playerLoaded', function(xPlayer)
  PlayerData = xPlayer
end)
