-------------------------------BY XOLAX GROUP DEVELOPMENT-----------------------------------------------------
ESX = nil

local pedwyciaganie = 0x3AE4A33B --hash peda
local drzwiwychodzenie = -1156992775







Citizen.CreateThread(function()
    exports.qtarget:AddTargetModel({pedwyciaganie}, {  --Nazwa Locala ALbo Hash Peda
        options = {
            {
                event = "xolax:mieszkania",  -- trigger eventa client side albo neteventa
                icon = "fas fa-door-open", -- ikonka na targecie mozna wziac ja z https://fontawesome.com 
                label = "WEJDŹ DO MIESZKANIA", -- Nazwa na targecie
            }
        },
        distance = 3.0 -- dystans
        })

end) 


Citizen.CreateThread(function()
    exports.qtarget:AddTargetModel({drzwiwychodzenie}, {  --Nazwa Locala ALbo Hash Peda
        options = {
            {
                event = "xolax:wyjdzmieszkania",  -- trigger eventa client side albo neteventa
                icon = "fas fa-door-closed", -- ikonka na targecie mozna wziac ja z https://fontawesome.com 
                label = "WYJDŹ Z MIESZKANIA", -- Nazwa na targecie
            }
        },
        distance = 3.0 -- dystans
        })

end) 


--EVENTY

