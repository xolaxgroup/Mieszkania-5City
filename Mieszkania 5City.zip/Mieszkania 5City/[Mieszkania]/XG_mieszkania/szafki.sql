INSERT INTO `addon_account` (`name`, `label`, `shared`) VALUES
('xolax', 'Schowek', 0),
('xolax_black_money', 'Schowek', 0);

INSERT INTO `addon_inventory` (`name`, `label`, `shared`) VALUES
('xolax', 'Schowek', 0);

INSERT INTO `datastore` (`name`, `label`, `shared`) VALUES
('xolax', 'Schowek', 0);