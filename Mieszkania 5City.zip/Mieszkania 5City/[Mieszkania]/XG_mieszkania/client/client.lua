-------------------------------BY XOLAX GROUP DEVELOPMENT-----------------------------------------------------
ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
      TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
      Citizen.Wait(25)
    end
  end)
  
  RegisterNetEvent('esx:playerLoaded')
  AddEventHandler('esx:playerLoaded', function(xPlayer)
    PlayerData = xPlayer
  end)
  
--Eventy do teleportu
  
  RegisterNetEvent("xolax:mieszkania")
  AddEventHandler("xolax:mieszkania", function()
  
      exports['dopeNotify2']:Alert("Mieszkanie", "Za 5 Sekund Zostaniesz Przeniesiony Do Mieszkania", 5000, 'info')
  
  
      
      TriggerServerEvent('InteractSound_SV:PlayOnSource', 'demo', 1)
  
      Citizen.Wait(5000)
      local playerPed = PlayerPedId()
  
      ESX.Game.Teleport(playerPed, {x = -821.33, y = 3476.28 , z = -159.59, heading = 247.56}, function()
          print('Przeniesiono Do Mieszkania!')
          local playerPed = PlayerPedId()

          Citizen.CreateThread(function()
          
              SetEntityVisible(playerPed, false)
          
              while true do
          
                  Citizen.Wait(0)
          
                  SetEntityLocallyVisible(playerPed)
          
              end
          
          end)
        

      end)
  end, false)
  
  
  
  RegisterNetEvent("xolax:wyjdzmieszkania")
  AddEventHandler("xolax:wyjdzmieszkania", function(jd)
  
      exports['dopeNotify2']:Alert("Mieszkanie", "Za 5 Sekund Wyjdziesz Z Mieszkania", 5000, 'info')
  
  
      
      TriggerServerEvent('InteractSound_SV:PlayOnSource', 'demo', 1)
  
      Citizen.Wait(5000)
      local playerPed = PlayerPedId()
  
      ESX.Game.Teleport(playerPed, {x = -268.88, y = -962.24 , z = 31.22, heading = 293.28}, function()
          print('Wyszedles Z Mieszkania!')
          local playerPed = PlayerPedId()

          Citizen.CreateThread(function()
          
              SetEntityVisible(playerPed, true)
          
              while true do
          
                  Citizen.Wait(0)
          
                  SetEntityLocallyVisible(playerPed)
          
              end
          
          end)
      end)
  end, false)


--blip
local blips = {
    {title="Mieszkanie", colour=0, id=40, x = -270.48, y = -957.66, z = 31.22}
    }      
    Citizen.CreateThread(function()
    
        for _, info in pairs(blips) do
        info.blip = AddBlipForCoord(info.x, info.y, info.z)
        SetBlipSprite(info.blip, info.id)
        SetBlipDisplay(info.blip, 4)
        SetBlipScale(info.blip, 1.0)
        SetBlipColour(info.blip, info.colour)
        SetBlipAsShortRange(info.blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(info.title)
        EndTextCommandSetBlipName(info.blip)
        end
      end)
      




    