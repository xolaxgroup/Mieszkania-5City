-------------------------------BY XOLAX GROUP DEVELOPMENT-----------------------------------------------------
local szafkamieszkania = -575561898
local przebieralniamieszkania = 684238724
local zapraszaniemieszkania = -1156992775
--ZMIENNE

Citizen.CreateThread(function()
    exports.qtarget:AddTargetModel({szafkamieszkania}, {  --Nazwa Locala ALbo Hash Peda
        options = {
            {
                event = "xolax:mieszkaniaszafka",  -- trigger eventa client side albo neteventa
                icon = "fas fa-box-open", -- ikonka na targecie mozna wziac ja z https://fontawesome.com 
                label = "OTWÓRZ SZAFKE", -- Nazwa na targecie
            }
        },
        distance = 3.0 -- dystans
        })

end) 

Citizen.CreateThread(function()
    exports.qtarget:AddTargetModel({przebieralniamieszkania}, {  --Nazwa Locala ALbo Hash Peda
        options = {
            {
                event = "xolax:mieszkaniaprzebieralnia",  -- trigger eventa client side albo neteventa
                icon = "fas fa-tshirt", -- ikonka na targecie mozna wziac ja z https://fontawesome.com 
                label = "OTWÓRZ PRZEBIERALNIE", -- Nazwa na targecie
            }
        },
        distance = 3.0 -- dystans
        })

end) 


Citizen.CreateThread(function()
    exports.qtarget:AddTargetModel({zapraszaniemieszkania}, {  --Nazwa Locala ALbo Hash Peda
        options = {
            {
                event = "xolax:zaprosdodomu",  -- trigger eventa client side albo neteventa
                icon = "fas fa-user-alt", -- ikonka na targecie mozna wziac ja z https://fontawesome.com 
                label = "ZAPROŚ DO MIESZKANIA", -- Nazwa na targecie
            }
        },
        distance = 3.0 -- dystans
        })

end) 

