
fx_version "bodacious"
games {"gta5"}
author {"XolaX Group Development"}
description {"Skrypt odpowiedzialny za hostowanie mieszkan szafki przebieralnie i teleportowanie"}

client_scripts {

'client/przebieralnia.lua',
'client/szafka.lua',
'client/client.lua',
'client/target.lua'
}


server_scripts { 
    'server/szafka.lua',
    'server/przebieralnia.lua'
}
