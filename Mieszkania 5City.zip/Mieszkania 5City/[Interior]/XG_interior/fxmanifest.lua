fx_version 'bodacious'
game 'gta5'
description 'interior mieszkania'

this_is_a_map 'yes'

files{ 
'interiorproxies.meta',
}

client_script 'client.lua'

data_file 'INTERIOR_PROXY_ORDER_FILE' 'interiorproxies.meta'